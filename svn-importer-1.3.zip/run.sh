#!/bin/bash
set +x
JAVA_OPTS=-Xmx100m
java $JAVA_OPTS -jar svnimporter.jar $*
